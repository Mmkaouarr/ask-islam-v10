
# Ask Islam (Final Site)
Sunni Muslim AI Q&A site with login, GPT chat, Stripe upgrades, webhook, Arabic toggle, and profile page.

## Quick Start
1) Copy `.env.example` to `.env.local` and fill in real keys.
2) `npm install`
3) `npm run dev`

## Deploy
Import to Vercel, add the same env vars, and deploy.
